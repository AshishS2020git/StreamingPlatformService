# Streaming Platform Service Database Management System 
# Authors:- Ashish Sujesh
from flask import Flask, render_template, request, redirect, url_for, session
from datetime import datetime,timedelta
import mysql.connector

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # needed for session management

# Connect to MySQL database
mycon = mysql.connector.connect(
    host="localhost",
    user="root",
    password="AshSQL@123",
    database="Streaming_Platform",
    connection_timeout=10
)
cursor = mycon.cursor(dictionary=True)

def signup(email, username, password, dob):
    account_role = "Free User"
    account_status = "Active"

    try:
        cursor.execute(
            "INSERT INTO USERS (Email, Username, Password, DOB, Account_Role, Account_Status) VALUES (%s, %s, %s, %s, %s, %s)",
            (email, username, password, dob, account_role, account_status)
        )
        mycon.commit()
        return True, "✅ Signup successful!"
    except mysql.connector.Error as err:
        mycon.rollback()
        return False, f"❌ Error: {err}"

def login(username, password):
    try:
        cursor.execute("SELECT User_ID, Username, Password, Account_Role FROM USERS WHERE Username = %s", (username,))
        user = cursor.fetchone()
        if user and password == user['Password']:
            try:
                cursor.execute("UPDATE USERS SET Last_Login = CURRENT_TIMESTAMP WHERE User_ID = %s", (user['User_ID'],))
                mycon.commit()
            except mysql.connector.Error as err:
                mycon.rollback()
            session['user_role'] = user['Account_Role']  # store role
            return user['User_ID'], user['Username']
        else:
            return None, "❌ Invalid username or password!"
    except mysql.connector.Error as err:
        mycon.rollback()
        return None, f"❌ Error: {err}"

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('home'))
    return redirect(url_for('login_route'))

@app.route('/signup', methods=['GET', 'POST'])
def signup_route():
    if request.method == 'POST':
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        dob = request.form['dob']
        success, message = signup(email, username, password, dob)
        if success:
            return redirect(url_for('login_route'))
        else:
            return message
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login_route():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user_id, result = login(username, password)
        if user_id:
            session['user_id'] = user_id
            session['username'] = result
            return redirect(url_for('home'))
        else:
            return result
    return render_template('login.html')

@app.route('/home')
def home():
    if 'user_id' not in session:
        return redirect(url_for('login_route'))

    query = """
        SELECT pc.*, 
               COALESCE(AVG(ui.Rating), 0) AS avg_rating, 
               COUNT(ui.Review) AS total_reviews
        FROM PLATFORM_CONTENT pc
        LEFT JOIN USER_INTERACTION ui ON pc.Content_ID = ui.Content_ID AND ui.Rating IS NOT NULL
        GROUP BY pc.Content_ID
        ORDER BY pc.Content_ReleaseDate DESC
        LIMIT 8
    """
    cursor.execute(query)
    preview_content = cursor.fetchall()

    return render_template('home.html', username=session['username'], preview_content=preview_content)



@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login_route'))

@app.route('/content')
def view_content():
    cursor.execute("""
        SELECT c.*, 
               ROUND(AVG(ui.Rating), 1) AS avg_rating
        FROM PLATFORM_CONTENT c
        LEFT JOIN USER_INTERACTION ui ON c.Content_ID = ui.Content_ID
        GROUP BY c.Content_ID
    """)
    content_list = cursor.fetchall()
    return render_template('content.html', contents=content_list)


@app.route('/watchlist')
def view_watchlist():
    if 'user_id' not in session:
        return redirect(url_for('login_route'))

    user_id = session['user_id']

    cursor.execute("""
        SELECT 
            PC.Content_ID, PC.Content_Title, PC.Content_Duration, PC.YouTube_Link,
            UI.Watch_Progress, UI.Rating, UI.Review
        FROM WATCHLIST W
        JOIN PLATFORM_CONTENT PC ON W.Content_ID = PC.Content_ID
        LEFT JOIN USER_INTERACTION UI ON PC.Content_ID = UI.Content_ID AND UI.User_ID = %s
        WHERE W.User_ID = %s
    """, (user_id, user_id))

    watchlist_items = cursor.fetchall()

    return render_template('watchlist.html', contents=watchlist_items)


@app.route('/add_to_watchlist/<int:content_id>')
def add_to_watchlist(content_id):
    if 'user_id' not in session:
        return redirect(url_for('login_route'))

    # Check if the content is already in the user's watchlist
    cursor.execute(
        "SELECT * FROM WATCHLIST WHERE User_ID = %s AND Content_ID = %s",
        (session['user_id'], content_id)
    )
    existing = cursor.fetchone()

    if existing:
        # Already in watchlist, maybe flash a message or just redirect silently
        # For now, just redirect without adding again
        return redirect(url_for('view_watchlist'))

    # If not present, insert it
    cursor.execute(
        "INSERT INTO WATCHLIST (User_ID, Content_ID) VALUES (%s, %s)",
        (session['user_id'], content_id)
    )
    mycon.commit()
    return redirect(url_for('view_watchlist'))



@app.route('/subscribe', methods=['GET', 'POST'])
def subscribe():
    if 'user_id' not in session:
        return redirect(url_for('login_route'))

    user_id = session['user_id']

    # Get the latest subscription
    cursor.execute("SELECT * FROM SUBSCRIPTIONS WHERE User_ID = %s ORDER BY Subscription_ID DESC LIMIT 1", (user_id,))
    current_sub = cursor.fetchone()

    if request.method == 'POST':
        plan = request.form['plan']
        mode = request.form['mode']
        start = datetime.today().date()
        end = start + timedelta(days=30)  # 30-day plan
        status = 'Active'
        payment_status = 'Paid'

        # Cancel previous active subscription if any
        if current_sub and current_sub['Subscription_Status'] == 'Active':
            cursor.execute("UPDATE SUBSCRIPTIONS SET Subscription_Status = 'Cancelled' WHERE Subscription_ID = %s", (current_sub['Subscription_ID'],))

        cursor.execute("""
            INSERT INTO SUBSCRIPTIONS (User_ID, Subscription_Plan, Start_Date, End_Date, Subscription_Status, Payment_Mode, Payment_Status)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (user_id, plan, start, end, status, mode, payment_status))

        sub_id = cursor.lastrowid
        amount = 0
        if plan == "Standard":
            amount = 149.99
        elif plan == "Premium":
            amount = 299.99

        cursor.execute("""
            INSERT INTO PAYMENTS (User_ID, Subscription_ID, Amount, Transaction_ID)
            VALUES (%s, %s, %s, %s)
        """, (user_id, sub_id, amount, 'TXN' + str(datetime.now().timestamp())))

        mycon.commit()
        return redirect(url_for('subscribe'))

    return render_template('subscribe.html', current_sub=current_sub)


@app.route('/cancel_subscription', methods=['POST'])
def cancel_subscription():
    if 'user_id' not in session:
        return redirect(url_for('login_route'))

    user_id = session['user_id']

    # Update the latest active subscription to cancelled
    cursor.execute("""
        UPDATE SUBSCRIPTIONS SET Subscription_Status = 'Cancelled'
        WHERE User_ID = %s AND Subscription_Status = 'Active'
    """, (user_id,))

    mycon.commit()
    return redirect(url_for('subscribe'))



@app.route('/notifications', methods=['GET', 'POST'])
def notifications():
    if 'user_id' not in session:
        return redirect(url_for('login_route'))

    # Fetch user role
    cursor.execute("SELECT Account_Role FROM USERS WHERE User_ID = %s", (session['user_id'],))
    role_row = cursor.fetchone()
    role = role_row['Account_Role'] if role_row else None

    sent_success = False

    if request.method == 'POST' and role == 'Administrator':
        target_user_id = request.form['target_user_id']
        message = request.form['message']
        notif_type = request.form['notif_type']

        cursor.execute(
            "INSERT INTO NOTIFICATIONS (User_ID, Message, Notification_Type) VALUES (%s, %s, %s)",
            (target_user_id, message, notif_type)
        )
        mycon.commit()
        sent_success = True

    # Fetch notifications for current user
    cursor.execute("SELECT * FROM NOTIFICATIONS WHERE User_ID = %s ORDER BY Sent_At DESC", (session['user_id'],))
    notes = cursor.fetchall()

    # If admin, fetch user list for dropdown
    users = []
    if role == 'Administrator':
        cursor.execute("SELECT User_ID, Username FROM USERS WHERE User_ID != %s", (session['user_id'],))
        users = cursor.fetchall()

    return render_template('notifications.html', notes=notes, user_role=role, sent_success=sent_success, users=users)




@app.route('/view/<int:content_id>')
def view_content_page(content_id):
    if 'user_id' not in session:
        return redirect(url_for('login_route'))
    try:
        cursor.execute("SELECT * FROM PLATFORM_CONTENT WHERE Content_ID = %s", (content_id,))
        content = cursor.fetchone()
        if content:
            return render_template('viewer.html', content=content)
        else:
            return "Content not found", 404
    except Exception as e:
        return f"Error: {str(e)}", 500

@app.route('/admin/add_youtube', methods=['GET', 'POST'])
def add_youtube_link():
    if 'user_id' not in session:
        return redirect(url_for('login_route'))

    cursor.execute("SELECT Account_Role FROM USERS WHERE User_ID = %s", (session['user_id'],))
    role = cursor.fetchone()

    if not role or role['Account_Role'] != 'Administrator':
        return "Unauthorized Access", 403

    if request.method == 'POST':
        content_title = request.form.get('content_title')
        content_genre = request.form.get('content_genre')
        content_description = request.form.get('content_description')
        content_language = request.form.get('content_language')
        content_release_date = request.form.get('content_release_date')
        content_duration = request.form.get('content_duration')  # Expecting HH:MM:SS
        youtube_link = request.form.get('youtube_link')
        content_status = request.form.get('content_status')

        if not all([content_title, content_genre, content_description, content_language,
                    content_release_date, content_duration, youtube_link, content_status]):
            return "All fields are required.", 400

        try:
            cursor.execute("""
                INSERT INTO PLATFORM_CONTENT 
                    (Content_Title, Content_Genre, Content_Description, Language, 
                    Content_ReleaseDate, Content_Duration, YouTube_Link, Content_Status)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                content_title, content_genre, content_description, content_language,
                content_release_date, content_duration, youtube_link, content_status
            ))
            mycon.commit()
            return redirect(url_for('view_content'))

        except Exception as e:
            mycon.rollback()
            return f"Database Error: {str(e)}", 500

    return render_template('add_youtube.html')




@app.route('/remove_from_watchlist/<int:content_id>', methods=['POST'])
def remove_from_watchlist(content_id):
    if 'user_id' not in session:
        return redirect(url_for('login_route'))
    try:
        cursor.execute("DELETE FROM WATCHLIST WHERE User_ID = %s AND Content_ID = %s", (session['user_id'], content_id))
        mycon.commit()
        return redirect(url_for('view_watchlist'))
    except mysql.connector.Error as err:
        mycon.rollback()
        return f"❌ Error removing content: {err}", 500
    
@app.route('/update_interaction/<int:content_id>', methods=['POST'])
def update_interaction(content_id):
    if 'user_id' not in session:
        return redirect(url_for('login_route'))

    user_id = session['user_id']
    progress = request.form.get('watch_progress')
    rating = request.form.get('rating')
    review = request.form.get('review')

    # Check if interaction exists
    cursor.execute("""
        SELECT * FROM USER_INTERACTION WHERE User_ID = %s AND Content_ID = %s
    """, (user_id, content_id))
    interaction = cursor.fetchone()

    if interaction:
        # Update existing
        cursor.execute("""
            UPDATE USER_INTERACTION
            SET Watch_Progress = %s, Rating = %s, Review = %s
            WHERE User_ID = %s AND Content_ID = %s
        """, (progress, rating or None, review, user_id, content_id))
    else:
        # Insert new
        cursor.execute("""
            INSERT INTO USER_INTERACTION (User_ID, Content_ID, Watch_Progress, Rating, Review)
            VALUES (%s, %s, %s, %s, %s)
        """, (user_id, content_id, progress, rating or None, review))

    mycon.commit()
    return redirect(url_for('view_watchlist'))

@app.route('/admin/delete_content/<int:content_id>', methods=['POST'])
def delete_content(content_id):
    if 'user_id' not in session:
        return redirect(url_for('login_route'))

    cursor.execute("SELECT Account_Role FROM USERS WHERE User_ID = %s", (session['user_id'],))
    role = cursor.fetchone()

    if not role or role['Account_Role'] != 'Administrator':
        return "Unauthorized Access", 403

    try:
        # Delete from related tables first to maintain referential integrity
        cursor.execute("DELETE FROM WATCHLIST WHERE Content_ID = %s", (content_id,))
        cursor.execute("DELETE FROM USER_INTERACTION WHERE Content_ID = %s", (content_id,))
        cursor.execute("DELETE FROM PLATFORM_CONTENT WHERE Content_ID = %s", (content_id,))
        mycon.commit()
        return redirect(url_for('view_content'))
    except mysql.connector.Error as err:
        mycon.rollback()
        return f"❌ Error deleting content: {err}", 500

@app.route('/admin/users')
def admin_user_management():
    if 'user_id' not in session:
        return redirect(url_for('login_route'))

    cursor.execute("SELECT Account_Role FROM USERS WHERE User_ID = %s", (session['user_id'],))
    role = cursor.fetchone()

    if not role or role['Account_Role'] != 'Administrator':
        return "Unauthorized Access", 403

    query = """
        SELECT 
            u.User_ID, u.Username, u.Account_Status,
            COALESCE(s.Subscription_Status, 'No Subscription') AS Subscription_Status,
            COALESCE(s.Payment_Status, 'Unpaid') AS Payment_Status
        FROM USERS u
        LEFT JOIN (
            SELECT s1.*
            FROM SUBSCRIPTIONS s1
            INNER JOIN (
                SELECT User_ID, MAX(Subscription_ID) AS MaxID
                FROM SUBSCRIPTIONS
                GROUP BY User_ID
            ) s2 ON s1.Subscription_ID = s2.MaxID
        ) s ON u.User_ID = s.User_ID
        ORDER BY u.User_ID
    """
    cursor.execute(query)
    users = cursor.fetchall()

    return render_template('admin_user_management.html', users=users)


@app.route('/admin/user/<int:user_id>/update', methods=['POST'])
def update_user_info(user_id):
    if session.get('user_role') != 'Administrator':
        return redirect('/home')

    account_status = request.form.get('account_status')
    subscription_status = request.form.get('subscription_status')
    payment_status = request.form.get('payment_status')

    cursor.execute("UPDATE USERS SET Account_Status=%s WHERE User_ID=%s", (account_status, user_id))
    cursor.execute("UPDATE SUBSCRIPTIONS SET Subscription_Status=%s, Payment_Status=%s WHERE User_ID=%s",
                   (subscription_status, payment_status, user_id))
    mycon.commit()
    return redirect('/admin/users')

@app.route('/admin/user/<int:user_id>/delete_reviews', methods=['POST'])
def delete_user_reviews(user_id):
    if session.get('user_role') != 'Administrator':
        return redirect('/home')

    cursor.execute("DELETE FROM USER_INTERACTION WHERE User_ID=%s AND Review IS NOT NULL", (user_id,))
    mycon.commit()
    return redirect('/admin/users')

@app.route('/admin/user/<int:user_id>/delete', methods=['POST'])
def delete_user_account(user_id):
    if session.get('user_role') != 'Administrator':
        return redirect('/home')

    cursor.execute("DELETE FROM USERS WHERE User_ID=%s", (user_id,))
    mycon.commit()
    return redirect('/admin/users')


if __name__ == "__main__":
    try:
        app.run(debug=True)
    finally:
        cursor.close()
        mycon.close()
